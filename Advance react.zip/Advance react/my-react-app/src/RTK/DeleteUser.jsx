import {React} from 'react'
import { useDispatch } from "react-redux";
import { removeuser } from "./UserSlice";

function DeleteUser()

{

    const dispatch = useDispatch()
    const DeletenewUser=(payload)=>{
            dispatch(removeuser(payload))

    }


return(
    <div>
        <button onClick={DeletenewUser()}>Delete user details</button>
    </div>
  
)
}

export default DeleteUser;
