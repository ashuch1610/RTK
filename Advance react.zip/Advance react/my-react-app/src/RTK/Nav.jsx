import {React} from 'react'



function Nav()
{

    return(
        <div >
            <ul style={{display: 'flex' }}>
            <li style={{ padding:'15px'}}>
                <a> Home</a>
                </li>
                <li style={{ padding:'15px'}}>
                <a>About</a>
                </li>
                <li style={{ padding:'15px'}}>
                <a>project</a>
                </li>
                <li style={{ padding:'15px'}}>
                <a>Code</a>
                </li>
                <li style={{ padding:'15px'}}>
                <a>Contact</a>
                </li>
            </ul>
        </div>
    )

}

export default Nav;