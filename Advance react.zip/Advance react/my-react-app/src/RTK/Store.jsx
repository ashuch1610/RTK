import { configureStore } from "@reduxjs/toolkit";
import users from "./UserSlice";

const store = configureStore(
    {
        reducer:{

            users1: users,
        
            },
    }
  
)

export default store;