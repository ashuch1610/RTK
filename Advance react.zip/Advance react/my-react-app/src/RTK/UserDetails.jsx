import {React} from 'react'
import DeleteUser from "../RTK/DeleteUser";
import { fakeUserData } from "./api";

import { useDispatch, useSelector } from "react-redux";
import { adduser } from "./UserSlice";
import DisplayUsers from './DisplayUsers';


function UserDetails()
{

    const dispatch = useDispatch(); 

    const addnewuser =(payload)=>{
        console.log(payload)
        dispatch(adduser(payload))

    }
return(
    <div>
        <button onClick={()=>{addnewuser(fakeUserData())}}>Add user details</button>
        <DisplayUsers/>
        <br/>
        <DeleteUser/>
    </div>
    
)
}

export default UserDetails;

