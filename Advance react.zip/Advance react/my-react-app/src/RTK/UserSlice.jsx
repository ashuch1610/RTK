import {  createSlice} from "@reduxjs/toolkit";



const users = createSlice(
    {
        name: 'user',
        initialState: [],
        reducers:{

            adduser(state, action){
                state.push(action.payload)
            },
            removeuser(state, action){
                state.pop(action.payload)
            },
            deleteuser(state, action){}
        
        }
    }
)

//export {users}
console.log(users.actions);

export default users.reducer;

export const {adduser , removeuser} = users.actions;
